package com.mindburned.blockersaycommand;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Core extends JavaPlugin {

    PluginDescriptionFile pdffile = this.getDescription();
    public String version = this.pdffile.getVersion();
    public String nombre = (Object)ChatColor.WHITE + "[" + (Object)ChatColor.DARK_AQUA + this.pdffile.getName() + (Object)ChatColor.WHITE + "]";
    public String latestversion;
    private PluginDescriptionFile plugin = this.getDescription();

    @Override
    public void onEnable() {
        ConsoleCommandSender c = Bukkit.getConsoleSender();
        updateChecker();
    }

    @Override
    public void onDisable() {
        ConsoleCommandSender c = Bukkit.getConsoleSender();
    }

    @EventHandler
    public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
        if (cmd.getName().equalsIgnoreCase("say") && !(sender instanceof Player)) {
            sender.sendMessage("");
        }
        return false;
    }

    public void updateChecker() {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection)new URL("https://api.spigotmc.org/legacy/update.php?resource=76435").openConnection();
            int n = 1250;
            httpURLConnection.setConnectTimeout(n);
            httpURLConnection.setReadTimeout(n);
            this.latestversion = new BufferedReader((Reader)new InputStreamReader(httpURLConnection.getInputStream())).readLine();
            if (this.latestversion.length() <= 7 && !this.version.equals((Object)this.latestversion)) {
                Bukkit.getConsoleSender().sendMessage((Object)ChatColor.RED + "There is a new version available. " + (Object)ChatColor.YELLOW + "(" + (Object)ChatColor.GRAY + this.latestversion + (Object)ChatColor.YELLOW + ")");
                Bukkit.getConsoleSender().sendMessage((Object)ChatColor.RED + "You can download it at: " + (Object)ChatColor.WHITE + "https://www.spigotmc.org/resources/76435/");
            }
        } catch (Exception exception) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf((Object)this.nombre) + (Object)ChatColor.RED + "Error while checking update.");
        }
    }

}